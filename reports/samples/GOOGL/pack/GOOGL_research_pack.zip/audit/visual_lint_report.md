# Visual Lint Report

Status: PASS

Checks:
- report_has_status_block
- report_has_toc
- chart_links_valid
- chart_explanations_present
- table_width_valid
- no_raw_nan
- no_raw_placeholder
- dashboard_exists
